// mrcctffindDlg.h : header file
//
//{{AFX_INCLUDES()
#include "msflexgrid.h"
//}}AFX_INCLUDES

#if !defined(AFX_MRCCTFFINDDLG_H__C74D0688_2826_4944_830B_DB15EE809197__INCLUDED_)
#define AFX_MRCCTFFINDDLG_H__C74D0688_2826_4944_830B_DB15EE809197__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMrcctffindDlg dialog

struct socketdata
{
	char filename[200];
	double drift;
};

struct Setting
{
	int		m_bin;
	int     m_box;
	float	m_cs;
	float	m_dfmax;
	float	m_dfmin;
	float	m_kv;
	float	m_mag;
	float	m_resmax;
	float	m_resmin;
	float	m_dfstep;
	float	m_wgh;
	int		m_port;
	float	m_trim;
	float   m_psize;
};

class CMrcctffindDlg : public CDialog
{
// Construction
public:
	void ReadSetting();
	void SaveSetting();
	int m_gridcount;
	CString m_result;
	int m_pwrbox;
	BYTE * m_pwrdata;
	bool DetermineDefocus(float *idata, int nx, int ny, float cs, float kv,
						float wgh, float xmag, float dstep, int box, 
						float resmin,float resmax,float dfmin, float dfmax, 
						float fstep,float &dfmid1, float &dfmid2, float &angast,
						float &cc,int ifpwr,float *pwr);
	CMrcctffindDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMrcctffindDlg)
	enum { IDD = IDD_MRCCTFFIND_DIALOG };
	CStatic	m_pwr;
	int		m_bin;
	int		m_box;
	float	m_cs;
	float	m_dfmax;
	float	m_dfmin;
	CString	m_filename;
	float	m_kv;
	float	m_mag;
	float	m_psize;
	float	m_resmax;
	float	m_resmin;
	float	m_dfstep;
	float	m_wgh;
	CString	m_mrcheader;
	int		m_port;
	CMSFlexGrid	m_grid;
	float	m_trim;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMrcctffindDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMrcctffindDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonGo();
	afx_msg void OnButtonBrowse();
	afx_msg void OnButtonListen();
	afx_msg void OnDblClickMsflexgrid1();
	afx_msg void OnClose();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MRCCTFFINDDLG_H__C74D0688_2826_4944_830B_DB15EE809197__INCLUDED_)
