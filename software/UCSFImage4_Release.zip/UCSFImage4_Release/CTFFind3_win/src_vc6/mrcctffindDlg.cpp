// mrcctffindDlg.cpp : implementation file
//

#include "stdafx.h"
#include "mrcctffind.h"
#include "mrcctffindDlg.h"
#include "MRC.h"
#include "CtrlUtil.h"
#include <Winsock2.h>
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

bool isListenUCSFImage;
BYTE *ppwr[5000];
int DimPwr[5000];
double Rdrift;


//Thread--functions
void ListenUCSFImagee3_Threadfunc()
{
	CCtrlUtil* pCtrlUtil = CCtrlUtil::GetInstance(AfxGetMainWnd());
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	
	wVersionRequested = MAKEWORD( 1, 1 );
	
	err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 ) 
	{
		AfxMessageBox("Failed to startup socket");
		return;
	}
	
	if ( LOBYTE( wsaData.wVersion ) != 1 ||	HIBYTE( wsaData.wVersion ) != 1 ) 
	{
		WSACleanup( );
		AfxMessageBox("Wrong socket Data version");
		return;
	}
	SOCKET sockSrv=socket(AF_INET,SOCK_STREAM,0);
	
	SOCKADDR_IN addrSrv;
	addrSrv.sin_addr.S_un.S_addr=htonl(INADDR_ANY);
	addrSrv.sin_family=AF_INET;
	addrSrv.sin_port=htons(pCtrlUtil->GetIntValue(IDC_EDIT_PORT));
	
	bind(sockSrv,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR));
	
	listen(sockSrv,5);
	pCtrlUtil->SetValue(IDC_BUTTON_LISTEN,"Listening");
	
	SOCKADDR_IN addrClient;
	int len=sizeof(SOCKADDR);
	while(1)
	{
		SOCKET sockConn=accept(sockSrv,(SOCKADDR*)&addrClient,&len);
		//char sendBuf[50];
		//sprintf(sendBuf,"Welcome %s to here!",inet_ntoa(addrClient.sin_addr));
		//send(sockConn,sendBuf,strlen(sendBuf)+1,0);
		socketdata sd;
		recv(sockConn,(char *)&sd,sizeof(socketdata),0);
		Rdrift=sd.drift;
		//printf("%s\n",recvBuf);
		pCtrlUtil->SetValue(IDC_EDIT_FILENAME,sd.filename);
		::PostMessage(AfxGetMainWnd()->m_hWnd,WM_COMMAND,MAKEWPARAM(IDC_BUTTON_GO,BN_CLICKED),0);

		closesocket(sockConn);
	}
}
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMrcctffindDlg dialog

CMrcctffindDlg::CMrcctffindDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMrcctffindDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMrcctffindDlg)
	m_bin = 4;
	m_box = 128;
	m_cs = 2.12f;
	m_dfmax = 30000.0f;
	m_dfmin = 10000.0f;
	m_filename = _T("");
	m_kv = 200.0f;
	m_mag = 100000.0f;
	m_psize = 7.37f;
	m_resmax = 10.0f;
	m_resmin = 200.0f;
	m_dfstep = 500.0f;
	m_wgh = 0.07f;
	m_mrcheader = _T("");
	m_port = 6000;
	m_trim = 0.0f;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMrcctffindDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMrcctffindDlg)
	DDX_Control(pDX, IDC_PWRWND, m_pwr);
	DDX_Text(pDX, IDC_EDIT_BINNING, m_bin);
	DDX_Text(pDX, IDC_EDIT_BOX, m_box);
	DDX_Text(pDX, IDC_EDIT_CS, m_cs);
	DDX_Text(pDX, IDC_EDIT_DFMAX, m_dfmax);
	DDX_Text(pDX, IDC_EDIT_DFMIN, m_dfmin);
	DDX_Text(pDX, IDC_EDIT_FILENAME, m_filename);
	DDX_Text(pDX, IDC_EDIT_KV, m_kv);
	DDX_Text(pDX, IDC_EDIT_MAG, m_mag);
	DDX_Text(pDX, IDC_EDIT_PSIZE, m_psize);
	DDX_Text(pDX, IDC_EDIT_RESMAX, m_resmax);
	DDX_Text(pDX, IDC_EDIT_RESMIN, m_resmin);
	DDX_Text(pDX, IDC_EDIT_STEP, m_dfstep);
	DDX_Text(pDX, IDC_EDIT_WGH, m_wgh);
	DDX_Text(pDX, IDC_STATIC_MRCHEADER, m_mrcheader);
	DDX_Text(pDX, IDC_EDIT_PORT, m_port);
	DDV_MinMaxInt(pDX, m_port, 1024, 65535);
	DDX_Control(pDX, IDC_MSFLEXGRID1, m_grid);
	DDX_Text(pDX, IDC_EDIT_TRIM, m_trim);
	DDV_MinMaxFloat(pDX, m_trim, 0.f, 49.f);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMrcctffindDlg, CDialog)
	//{{AFX_MSG_MAP(CMrcctffindDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_GO, OnButtonGo)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnButtonBrowse)
	ON_BN_CLICKED(IDC_BUTTON_LISTEN, OnButtonListen)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMrcctffindDlg message handlers

BOOL CMrcctffindDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_pwrbox=0;
	m_pwrdata=NULL;

	isListenUCSFImage=false;

	//init grid
	m_grid.Clear();
	m_grid.SetColWidth(0,600);
	m_grid.SetColAlignment(0,6);
	m_grid.SetTextMatrix(0,0,"ID");

	m_grid.SetColWidth(1,1800);
	m_grid.SetColAlignment(1,6);
	m_grid.SetTextMatrix(0,1,"FileName");

	m_grid.SetColWidth(2,1100);
	m_grid.SetColAlignment(2,6);
	m_grid.SetTextMatrix(0,2,"Df1");

	m_grid.SetColWidth(3,1100);
	m_grid.SetColAlignment(3,6);
	m_grid.SetTextMatrix(0,3,"Df2");

	m_grid.SetColWidth(4,1100);
	m_grid.SetColAlignment(4,6);
	m_grid.SetTextMatrix(0,4,"Diff");

	m_grid.SetColWidth(5,800);
	m_grid.SetColAlignment(5,6);
	m_grid.SetTextMatrix(0,5,"Angast");

	m_grid.SetColWidth(6,1000);
	m_grid.SetColAlignment(6,6);
	m_grid.SetTextMatrix(0,6,"CC");

	m_grid.SetColWidth(7,1000);
	m_grid.SetColAlignment(7,6);
	m_grid.SetTextMatrix(0,7,"Drift");

	m_gridcount=0;

	memset(ppwr,0,sizeof(BYTE *)*5000);

	Rdrift=0.0;

	ReadSetting();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMrcctffindDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMrcctffindDlg::OnPaint() 
{
	CDC *pDC=m_pwr.GetDC();
	int i,j,ip,id,x,y;
	int lt=128-m_pwrbox/2;
	for(i=0;i<m_pwrbox;i++)
	{
		ip=i*m_pwrbox;
		for(j=0;j<m_pwrbox;j++)
		{
			id=ip+j;
			x=j+lt;
			y=i+lt;
			if(x<0 || x>=256 || y<0 || y>=256) continue;
			pDC->SetPixel(x,y,RGB(m_pwrdata[id],m_pwrdata[id],m_pwrdata[id]));
		}
	}
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMrcctffindDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

bool CMrcctffindDlg::DetermineDefocus(float *idata, int nx, int ny, float cs, float kv,
									  float wgh, float xmag, float dstep, int box, 
									  float resmin,float resmax,float dfmin, float dfmax, 
									  float fstep,float &dfmid1, float &dfmid2, float &angast,
									  float &cc,int ifpwr,float *pwr)
{
	typedef void (_stdcall *MYPROC)(float *idata, int *nx, int *ny, float *cs, float *kv,float *wgh, float *xmag, float *dstep, int *box, float *resmin,float *resmax,float *dfmin, float *dfmax, float *fstep,float *dfmid1, float *dfmid2, float *angast,float *cc,int *ifpwr,float *pwr);

	HINSTANCE hDLL;
	MYPROC ctffind;
	hDLL=LoadLibrary("ctffind33.dll");
	if(hDLL!=NULL)
	{
		ctffind=(MYPROC)GetProcAddress(hDLL,"_CTFFIND3@80");
	}
	else
	{
		AfxMessageBox("Failed to load ctffind33.dll");
		return false;
	}

	/*MRC mrc;
	int r=mrc.open("image_0730_4x.mrc","rb");
	idata=new float[nx*ny];
	mrc.read2DIm((void *)data,0);
	delete [] idata;
	mrc.close();*/
		
	ctffind(idata, &nx, &ny, &cs, &kv, &wgh, &xmag, &dstep, &box, &resmin,
		&resmax,&dfmin, &dfmax, &fstep,&dfmid1, &dfmid2, &angast, &cc,&ifpwr,pwr);
	
	FreeLibrary(hDLL);

	return true;
}

void CMrcctffindDlg::OnButtonGo() 
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	
	MRC mrc;
	if(mrc.open((LPCTSTR)m_filename,"rb")<=0)
	{	
		AfxMessageBox("Wrong MRC file! Abort.");
		return;
	}

	m_mrcheader.Format("Nx  =%7d    Ny  =%7d  Mode=%7d\r\nMean=%7.2f    Min =%7.2f  Max =%7.2f",
		mrc.getNx(),mrc.getNy(),mrc.getMode(),mrc.getMean(),mrc.getMin(),mrc.getMax());
	UpdateData(false);

	float df1,df2,angast,cc;
	float *bim;
	int nxb,nyb;
	if(m_bin!=1)
	{
		m_result="Binning image...";
		UpdateData(false);
	}
	mrc.getBinIm(&bim,nxb,nyb,m_bin, m_trim);
	if(bim==NULL)
	{
		m_result="Failed to binning Image.";
		UpdateData(false);
		mrc.close();
		return;
	}
	mrc.close();
	
	m_gridcount++;
	m_result.Format("%d",m_gridcount);
	m_grid.SetTextMatrix(m_gridcount,0,(LPCTSTR)m_result);

	m_result=m_filename.Right(m_filename.GetLength()-m_filename.ReverseFind('\\')-1);
	m_grid.SetTextMatrix(m_gridcount,1,(LPCTSTR)m_result);

	m_result="Calculating...";
	m_grid.SetTextMatrix(m_gridcount,2,(LPCTSTR)m_result);

	int ifpwr=1;
	float *pwr=new float[m_box*m_box];
	DetermineDefocus(bim,nxb,nyb,m_cs,m_kv,m_wgh,m_mag,m_psize*m_bin,m_box,
				m_resmin,m_resmax,m_dfmin,m_dfmax,m_dfstep,df1,df2,angast,cc,ifpwr,pwr);
	delete [] bim;
	bim=NULL;

	m_result.Format("%8.0f",df1);
	m_grid.SetTextMatrix(m_gridcount,2,(LPCTSTR)m_result);

	m_result.Format("%8.0f",df2);
	m_grid.SetTextMatrix(m_gridcount,3,(LPCTSTR)m_result);

	m_result.Format("%8.0f",df1-df2);
	m_grid.SetTextMatrix(m_gridcount,4,(LPCTSTR)m_result);
	if(fabs(df1-df2)>1000)
	{
		m_grid.SetRow(m_gridcount);
		m_grid.SetCol(4);
		if(fabs(df1-df2)<1500) m_grid.SetCellBackColor(0x0000FFFF);
		if(fabs(df1-df2)>=1500) m_grid.SetCellBackColor(0x000000FF);
	}

	m_result.Format("%6.2f",angast);
	m_grid.SetTextMatrix(m_gridcount,5,(LPCTSTR)m_result);

	m_result.Format("%6.4f",cc);
	m_grid.SetTextMatrix(m_gridcount,6,(LPCTSTR)m_result);
	if(cc<0.1)
	{
		m_grid.SetRow(m_gridcount);
		m_grid.SetCol(6);
		if(cc>0.0) m_grid.SetCellBackColor(0x0000FFFF);
		if(cc<=0.0) m_grid.SetCellBackColor(0x000000FF);
	}

	m_result.Format("%6.2f",Rdrift);
	m_grid.SetTextMatrix(m_gridcount,7,(LPCTSTR)m_result);

	Rdrift=0.0;
	
	int toprow=m_gridcount-11;
	if(toprow<1) toprow=1;
	m_grid.SetTopRow(toprow);

	UpdateData(false);

	//draw pwr
	float min=pwr[0],max=pwr[0];
	int size=m_box*m_box,i;
	for(i=0;i<size;i++)
	{
		if(min>pwr[i]) min=pwr[i];
		if(max<pwr[i]) max=pwr[i];
	}
	if((max-min)==0.0) 
	{
		delete [] pwr;
		return;
	}
	double scale=256.0/double(max-min);
	m_pwrbox=m_box;
	if(m_pwrdata!=NULL) 
	{
		delete [] m_pwrdata;
		m_pwrdata=NULL;
	}
	m_pwrdata=new BYTE[size];
	double pix;
	for(i=0;i<size;i++)
	{
		pix=int((pwr[i]-min)*scale+0.5);
		if(pix>255) pix=255;
		if(pix<0) pix=255;
		m_pwrdata[i]=int(pix);
	}
	delete [] pwr;
	ppwr[m_gridcount]=new BYTE[size];
	memcpy(ppwr[m_gridcount],m_pwrdata,sizeof(BYTE)*size);
	DimPwr[m_gridcount]=m_pwrbox;
	Invalidate(false);
}

void CMrcctffindDlg::OnButtonBrowse() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(false,NULL,NULL,NULL,"MRC file(*.mrc)|*.mrc|All file(*.*)|*.*||",NULL);
	MRC mrc;
	if(dlg.DoModal()==IDOK)
	{
		UpdateData(true);
		m_filename=dlg.GetPathName();
			
		if(mrc.open((LPCTSTR)m_filename,"rb")<=0)
		{	
			m_mrcheader="Bad file!";
		}
		else
		{
			m_mrcheader.Format("Nx  =%7d    Ny  =%7d  Mode=%7d\r\nMean=%7.2f    Min =%7.2f  Max =%7.2f",
				mrc.getNx(),mrc.getNy(),mrc.getMode(),mrc.getMean(),mrc.getMin(),mrc.getMax());
		}

		mrc.close();

		UpdateData(false);
	}
}

void CMrcctffindDlg::OnButtonListen() 
{
	// TODO: Add your control notification handler code here
	HANDLE hThread;
	DWORD ThreadID;

	if(!isListenUCSFImage)
	{
		hThread=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)ListenUCSFImagee3_Threadfunc,
				NULL,0,&ThreadID);	
		isListenUCSFImage=true;
	}
	
}

BEGIN_EVENTSINK_MAP(CMrcctffindDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CMrcctffindDlg)
	ON_EVENT(CMrcctffindDlg, IDC_MSFLEXGRID1, -601 /* DblClick */, OnDblClickMsflexgrid1, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CMrcctffindDlg::OnDblClickMsflexgrid1() 
{
	// TODO: Add your control notification handler code here
	int row=m_grid.GetRowSel();
	if(row>m_gridcount || row==0) return;
	if(m_pwrdata!=NULL) delete [] m_pwrdata;
	m_pwrbox=DimPwr[row];
	m_pwrdata=new BYTE[m_pwrbox*m_pwrbox];
	memcpy(m_pwrdata,ppwr[row],sizeof(BYTE)*m_pwrbox*m_pwrbox);

	Invalidate(false);
}

void CMrcctffindDlg::SaveSetting()
{
	UpdateData(true);
	Setting s;
	s.m_bin=m_bin;
	s.m_box=m_box;
	s.m_cs=m_cs;
	s.m_dfmax=m_dfmax;
	s.m_dfmin=m_dfmin;
	s.m_dfstep=m_dfstep;
	s.m_kv=m_kv;
	s.m_mag=m_mag;
	s.m_port=m_port;
	s.m_resmax=m_resmax;
	s.m_resmin=m_resmin;
	s.m_trim=m_trim;
	s.m_wgh=m_wgh;
	s.m_psize=m_psize;


	char strPathName[_MAX_PATH];
	::GetModuleFileName(NULL, strPathName, _MAX_PATH);

	// The following code will allow you to get the path.
	CString newPath(strPathName);
	int fpos = newPath.ReverseFind('\\');

	if (fpos != -1)
	newPath = newPath.Left(fpos + 1)+"ctffind.dat";


	FILE *fp=fopen((LPCTSTR)newPath,"wb");
	if(fp==NULL) 
	{
		MessageBox("Failed to write setting file");
		return;
	}
	fwrite(&s,1,sizeof(Setting),fp);
	fclose(fp);
}

void CMrcctffindDlg::ReadSetting()
{
	char strPathName[_MAX_PATH];
	::GetModuleFileName(NULL, strPathName, _MAX_PATH);

	// The following code will allow you to get the path.
	CString newPath(strPathName);
	int fpos = newPath.ReverseFind('\\');

	if (fpos != -1)
	newPath = newPath.Left(fpos + 1)+"ctffind.dat";

	FILE *fp=fopen((LPCTSTR)newPath,"rb");
	if(fp==NULL) 
	{
		MessageBox("Failed to read setting file");
		return;
	}
	Setting s;
	fread(&s,1,sizeof(Setting),fp);
	fclose(fp);

	m_bin=s.m_bin;
	m_box=s.m_box;
	m_cs=s.m_cs;
	m_dfmax=s.m_dfmax;
	m_dfmin=s.m_dfmin;
	m_dfstep=s.m_dfstep;
	m_kv=s.m_kv;
	m_mag=s.m_mag;
	m_port=s.m_port;
	m_resmax=s.m_resmax;
	m_resmin=s.m_resmin;
	m_trim=s.m_trim;
	m_wgh=s.m_wgh;
	m_psize=s.m_psize;

	UpdateData(false);
}

void CMrcctffindDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	SaveSetting();
	
	CDialog::OnClose();
}
