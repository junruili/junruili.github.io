// CtrlUtil.h: interface for the CCtrlUtil class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTRLUTIL_H__7E301686_C53C_4E2E_809A_747E667ADE6C__INCLUDED_)
#define AFX_CTRLUTIL_H__7E301686_C53C_4E2E_809A_747E667ADE6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCtrlUtil  
{
public:
	void Move(int iCtrlID, int x, int y);

	static CCtrlUtil* GetInstance(CWnd* pParentWnd);

	static void DeleteInstance(void);

	~CCtrlUtil(void);

	void HideCtrl(int iCtrlID, bool bHide);

	void EnableCtrl(int iCtrlID, bool bEnable);

	void CheckCtrl(int iCtrlID, bool bCheck);

	bool IsChecked(int iCtrlID);

	bool IsEmpty(int iCtrlID);

	void SetValue(int iCtrlID, int iValue);

	void SetValue(int iCtrlID, float fValue);

	void SetValue(int iCtrlID, char* pcValue);

	int GetCurSel(int iCtrlID);

	void SetCurSel(int iCtrlID, int iIndex);

	char* GetCharValue(int iCtrlID);	/* [out] */

	int GetIntValue(int iCtrlID);

	float GetFloatValue(int iCtrlID);

	void SetFocus(int iCtrlID, bool bSetFocus);

private:

	CCtrlUtil(void);

	static CCtrlUtil* m_pInstance;

	CWnd* m_pParentWnd;

};

#endif // !defined(AFX_CTRLUTIL_H__7E301686_C53C_4E2E_809A_747E667ADE6C__INCLUDED_)
