// MRC.cpp: implementation of the MRC class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MRC.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
MRC::MRC()
{
	memset((void *)&m_header,0,sizeof(MRCHeader));
	m_fp=NULL;
}

MRC::MRC(const char *filename, const char *mode)
{
	MRC();
	open(filename,mode);
}

MRC::~MRC()
{

}

int MRC::open(const char *filename, const char *mode)
{
	close();
	m_fp=fopen(filename,mode);
	if(m_fp==NULL) return 0;
	
	//read file header
	rewind(m_fp);
	if(fread(&m_header,1,1024,m_fp)<1024) return -1;
	
	return 1;
}

void MRC::close()
{
	if(m_fp!=NULL) fclose(m_fp);
	m_fp=NULL;
}

void MRC::printInfo()
{
	if(m_fp==NULL) 
	{
		printf("No MRC file was opened!");
		return;
	}
	
	printf("\tMRC Header size:                   %12d\n",sizeof(MRCHeader));
	printf("\tNum of columns, rows,sections:     %12d %12d %12d\n",m_header.nx,m_header.ny,m_header.nz);
	printf("\tMode:                              %12d\n",m_header.mode);
	printf("\tNum of First column, row, section: %12d %12d %12d\n",m_header.nxstart, m_header.nystart, m_header.nzstart);
	printf("\tNum of intervals along x, y, z:    %12d %12d %12d\n",m_header.mx,m_header.my,m_header.mz);
	printf("\tCell dimensions in angstroms:      %12.3f %12.3f %12.3f\n",m_header.cella[0], m_header.cella[1],m_header.cella[2]);
	printf("\tCell angles in degrees:            %12.3f %12.3f %12.3f\n",m_header.cellb[0], m_header.cellb[1],m_header.cellb[2]);
	printf("\tAxis for cols, rows, sections:     %12d %12d %12d\n",m_header.mapc, m_header.mapr, m_header.maps);
	printf("\tMin, max, mean density value:      %12.3f %12.3f %12.3f\n",m_header.dmin, m_header.dmax, m_header.dmean);
	printf("\tSpace group number:                %12d\n",m_header.ispg);
	printf("\tNum of bytes for symmetry data:    %12d\n",m_header.nsymbt);
	//printf("\tExtra:                             %s\n",m_header.extra);
	printf("\tOrigin in X,Y,Z:                   %12.3f %12.3f %12.3f\n",m_header.origin[0], m_header.origin[1], m_header.origin[2]);
	printf("\tFile type:                         %c%c%c%c\n",m_header.map[0],m_header.map[1],m_header.map[2],m_header.map[3]);
	printf("\tMachine stamp:                     %12d\n",m_header.machst);
	printf("\trms deviationfrom mean density:    %12.3f\n",m_header.rms);
	printf("\tNum of labels being used:          %12d\n",m_header.nlabels);
	for(int i=0;i<m_header.nlabels;i++)
	{
		printf("\t\t%s\n",m_header.label[i]);
	}
}

void MRC::getHeader(const MRCHeader *pheader)
{
	memcpy((void *)pheader, (void *)&m_header, 1024);
}

int MRC::getNx()
{
	return m_header.nx;
}

int MRC::getNy()
{
	return m_header.ny;
}

int MRC::getNz()
{
	return m_header.nz;
}

int MRC::getWordLength()
{
	switch(m_header.mode)
	{
		case 0:
			return 1;
		case 1:
			return 2;
		case 2:
			return 4;
		case 3:
			return 4;
		case 4:
			return 8;
		case 6:
			return 2;
	}
	
	return 0;
}

int MRC::getImSize()
{
	return getNx()*getNy()*getWordLength();
}

int MRC::getMode()
{
	return m_header.mode;
}

int MRC::getSymdatasize()
{
	return m_header.nsymbt;
}

float MRC::getMin()
{
	return m_header.dmin;
}

float MRC::getMax()
{
	return m_header.dmax;
}

float MRC::getMean()
{
	return m_header.dmean;
}

	
int MRC::read2DIm(void *buf, int n)
{
	int ImSize=getImSize();
	long offset=1024+getSymdatasize()+n*ImSize;
	if(fseek(m_fp, offset, SEEK_SET)!=0) return 0;
	return fread(buf, 1, ImSize, m_fp);
}

int MRC::readLine(void *buf, int nimage, int nline)
{
	int ImSize=getImSize();
	int LineLength=getNy()*getWordLength();
	long offset=1024+getSymdatasize()+nimage*ImSize+nline*LineLength;
	if(fseek(m_fp, offset, SEEK_SET)!=0) return 0;
	return fread(buf, 1, LineLength, m_fp);
}

int MRC::readPixel(void *buf, int nimage, int nline, int npixel)
{
	int ImSize=getImSize();
	int LineLength=getNy()*getWordLength();
	if(npixel>=LineLength) return 0;
	long offset=1024+getSymdatasize()+nimage*ImSize+nline*LineLength+npixel*getWordLength();
	if(fseek(m_fp, offset, SEEK_SET)!=0) return 0;
	return fread(buf, 1, getWordLength(), m_fp);
}

int MRC::readnPixels(void *buf, int nimage, int nline, int npixel, int n)
{
        int ImSize=getImSize();
        int LineLength=getNy()*getWordLength();
        if(npixel>=LineLength) return 0;
        long offset=1024+getSymdatasize()+nimage*ImSize+nline*LineLength+npixel*getWordLength();
        if(fseek(m_fp, offset, SEEK_SET)!=0) return 0;
        return fread(buf, 1, n*getWordLength(), m_fp);
}

int MRC::write2DIm(void *buf, int n)
{
	int ImSize=getImSize();
	long offset=1024+getSymdatasize()+n*ImSize;
	if(fseek(m_fp, offset, SEEK_SET)!=0) return 0;
	return fwrite(buf, 1, ImSize, m_fp);
}

int MRC::writeLine(void *buf, int nimage, int nline)
{
	int ImSize=getImSize();
	int LineLength=getNy()*getWordLength();
	long offset=1024+getSymdatasize()+nimage*ImSize+nline*LineLength;
	if(fseek(m_fp, offset, SEEK_SET)!=0) return 0;
	return fwrite(buf, 1, LineLength, m_fp);
}

int MRC::writePixel(void *buf, int nimage, int nline, int npixel)
{
	int ImSize=getImSize();
	int LineLength=getNy()*getWordLength();
	if(npixel>=LineLength) return 0;
	long offset=1024+getSymdatasize()+nimage*ImSize+nline*LineLength+npixel*getWordLength();
	if(fseek(m_fp, offset, SEEK_SET)!=0) return 0;
	return fwrite(buf, 1, getWordLength(), m_fp);
}

void MRC::setHeader(const MRCHeader *pheader)
{
	memcpy((void *)&m_header, (void *)pheader, 1024);
	rewind(m_fp);
	fwrite(&m_header,1,1024,m_fp);
}

void MRC::setMin(float min)
{
	m_header.dmin=min;
}

void MRC::setMax(float max)
{
	m_header.dmax=max;
}

void MRC::setMean(float mean)
{
	m_header.dmean=mean;
}

void MRC::updateHeader()
{
	rewind(m_fp);
	fwrite(&m_header,1,1024,m_fp);
}

void MRC::getBinIm(float **pBinIm, int &ix, int &iy, int bin, float trim)
{
	*pBinIm=NULL;
	if(m_fp==NULL) return;
	if(bin<=0) return;

	int size=getImSize();
	if(size==0) return;
	int nx=getNx();
	int ny=getNy();
    
	int offsetx=nx*(trim/100.0)+0.5000001;
	int offsety=ny*(trim/100.0)+0.5000001;
	int nxt=nx-2*offsetx;
	int nyt=ny-2*offsety;
	nxt=(nxt/(2*bin))*(2*bin);
	nyt=(nyt/(2*bin))*(2*bin);
	if(nxt<4 || nyt<4) return;
	int offsetx1=offsetx+nxt;
	int offsety1=offsety+nyt;
	
	int nxbin=nxt/bin;
	int nybin=nyt/bin;

	int mode=getMode();
	if(mode!=1 && mode!=2) return;
	ix=nxbin;
	iy=nybin;

	char *buf=new char[size];
	if(read2DIm(buf,0)!=size) 
	{
		delete [] buf;
		return;
	}
	float *pIm=new float[nxbin*nybin];
	*pBinIm=pIm;

	memset(pIm,0,sizeof(float)*nxbin*nybin);

	short *buf16=(short *)buf;
	float *buf32=(float *)buf;
	
	float bin2=float(bin*bin);
	int x,y,pos,posl,posb,posbl;
	for(x=offsetx;x<offsetx1;x++)
	{	
		posl=x*ny;
		posbl=((x-offsetx)/bin)*nybin;
		for(y=offsety;y<offsety1;y++)
		{
			pos=posl+y;
			posb=posbl+(y-offsety)/bin;
			if(mode==1) pIm[posb]+=buf16[pos]/bin2;
			else pIm[posb]+=buf32[pos]/bin2;
		}
	}
	


	delete [] buf;
}
