// CtrlUtil.cpp: implementation of the CCtrlUtil class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "mrcctffind.h"
#include "CtrlUtil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCtrlUtil* CCtrlUtil::m_pInstance = NULL;

CCtrlUtil* CCtrlUtil::GetInstance(CWnd* pParentWnd)
{
	if(m_pInstance == NULL) m_pInstance = new CCtrlUtil;
	m_pInstance->m_pParentWnd = pParentWnd;
	return m_pInstance;
}

void CCtrlUtil::DeleteInstance(void)
{
	if(m_pInstance == NULL) return;
	delete m_pInstance;
	m_pInstance = NULL;
}

CCtrlUtil::CCtrlUtil(void)
{
	m_pParentWnd = NULL;
}

CCtrlUtil::~CCtrlUtil(void)
{
}

void CCtrlUtil::HideCtrl(int iCtrlID, bool bHide)
{
	CWnd* pCtrlWnd = m_pParentWnd->GetDlgItem(iCtrlID);
	if(bHide) pCtrlWnd->ShowWindow(SW_HIDE);
	else pCtrlWnd->ShowWindow(SW_SHOW);
}

void CCtrlUtil::EnableCtrl(int iCtrlID, bool bEnable)
{	
	CWnd* pWnd = m_pParentWnd->GetDlgItem(iCtrlID);
	pWnd->EnableWindow(bEnable);
}

void CCtrlUtil::CheckCtrl(int iCtrlID, bool bCheck)
{	
	if(bCheck) m_pParentWnd->CheckDlgButton(iCtrlID, BST_CHECKED);
	else m_pParentWnd->CheckDlgButton(iCtrlID, BST_UNCHECKED);
}

bool CCtrlUtil::IsChecked(int iCtrlID)
{
	if(m_pParentWnd->IsDlgButtonChecked(iCtrlID)) return true;
	else return false;
}

bool CCtrlUtil::IsEmpty(int iCtrlID)
{
	char* pcVal = this->GetCharValue(iCtrlID);
	if(pcVal == NULL) return true;
	delete[] pcVal;
	return false;
}

void CCtrlUtil::SetValue(int iCtrlID, int iValue)
{
	TCHAR tcVal[128];
	sprintf(tcVal, "%d", iValue);
	CWnd* pWnd = m_pParentWnd->GetDlgItem(iCtrlID);
	pWnd->SetWindowText(tcVal);
}

void CCtrlUtil::SetValue(int iCtrlID, float fValue)
{
	TCHAR tcVal[128];
	sprintf(tcVal, "%.2f", fValue);
	CWnd* pWnd = m_pParentWnd->GetDlgItem(iCtrlID);
	pWnd->SetWindowText(tcVal);
}

void CCtrlUtil::SetValue(int iCtrlID, char* pcValue)
{
	if(pcValue == NULL) return;
	CWnd* pWnd = m_pParentWnd->GetDlgItem(iCtrlID);
	pWnd->SetWindowText(pcValue);
}

void CCtrlUtil::SetCurSel(int iCtrlID, int iIndex)
{
	CWnd* pWnd= m_pParentWnd->GetDlgItem(iCtrlID);
	CComboBox* pComboBox = (CComboBox*)pWnd;
	pComboBox->SetCurSel(iIndex);
}

int CCtrlUtil::GetCurSel(int iCtrlID)
{
	CWnd* pWnd= m_pParentWnd->GetDlgItem(iCtrlID);
	CComboBox* pComboBox = (CComboBox*)pWnd;
	return pComboBox->GetCurSel();
}

char* CCtrlUtil::GetCharValue(int iCtrlID)
{
	CWnd* pWnd= m_pParentWnd->GetDlgItem(iCtrlID);
	char* pcVal = new char[256];
	memset(pcVal, 0, sizeof(char) * 256);
	int iLength = ::GetWindowText(pWnd->m_hWnd, pcVal, 255);
	if(iLength != 0) return pcVal;
	delete[] pcVal;
	return NULL;
}

int CCtrlUtil::GetIntValue(int iCtrlID)
{
	char* pcVal = this->GetCharValue(iCtrlID);
	if(pcVal == NULL) return 0;
	int iVal = atoi(pcVal);
	delete[] pcVal;
	return iVal;
}

float CCtrlUtil::GetFloatValue(int iCtrlID)
{
	char* pcVal = this->GetCharValue(iCtrlID);
	if(pcVal == NULL) return 0.0f;
	float fVal = (float)atof(pcVal);
	delete[] pcVal;
	return fVal;
}

void CCtrlUtil::SetFocus(int iCtrID, bool bSetFocus)
{
	CWnd* pWnd = m_pParentWnd->GetDlgItem(iCtrID);
	if(bSetFocus) pWnd->SetFocus();
	else m_pParentWnd->SetFocus();
}

void CCtrlUtil::Move(int iCtrlID, int x, int y)
{
	CWnd* pWnd = m_pParentWnd->GetDlgItem(iCtrlID);
	CRect aRect;
	pWnd->GetClientRect(&aRect);
	pWnd->MoveWindow(x, y, aRect.right, aRect.bottom, true);

}
