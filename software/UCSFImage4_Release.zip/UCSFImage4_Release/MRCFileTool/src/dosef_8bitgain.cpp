#include "mrc.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string.h>

using namespace std;


void MinMaxMean(float *pbuf, int size, float &min, float &max, double &mean)
{
	int i;
	double dmean=0;
	for(i=0;i<size;i++)
	{
		if(pbuf[i]<min) min=pbuf[i];
		if(pbuf[i]>max) max=pbuf[i];
		dmean+=pbuf[i];
	}
	mean+=(dmean/size);
}



//INPUT1: 1Input.mrc 2Output.mrc
//INPUT2: 1Input.mrc 2Output.mrc 3bGain

int main(int narg, char *argc[])
{

	if(narg==1)
    {
        printf("\n  Extract Gain Reference from Extended Header(8bit MRC in mode 5)\n\n");
        printf("    INPUT: Input.mrc Output.mrc\n\n");
        printf("      *Note: Input must be the 8bit file from UCSFImage\n");

        printf("    Wrote by Xueming Li @ Tsinghua University\n");
        return 1;
    }
    if(narg!=3)
    {
        perror("   Missing arguments!\n");
        return 0;
    }
    

	MRC input;
	if(input.open(argc[1],"rb")<=0)
	{
		printf("Failed to read %s . Abort\n",argc[1]);
		return 1;
	}
	
	MRCHeader header;
	input.getHeader(&header);
	
	int mode=input.getMode();
	if(mode!=5) 
	{
		printf("Input file must be the 8bit file (mode=5). Abort\n");
		return 1;
	}
	
	int nx=input.getNx();
	int ny=input.getNy();
	int nz=input.getNz();
	int size=nx*ny;
	
	float *pGain=NULL;
	pGain=new float[size];
	if(input.readGainInHeader(pGain)==0)
	{
		delete [] pGain;
		pGain=NULL;
		input.close();
		printf("Failed to read gain map from extended header. Abort\n");
		return 1;
	}

	input.close();
	
	MRC output;
	output.open(argc[2],"wb");
	
	output.createMRC(pGain,nx,ny,1);
	
	output.close();

	if(pGain!=NULL) delete [] pGain;

	return 0;
}













