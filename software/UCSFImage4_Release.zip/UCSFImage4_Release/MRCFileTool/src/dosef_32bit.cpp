#include "mrc.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string.h>

using namespace std;


void MinMaxMean(float *pbuf, int size, float &min, float &max, double &mean)
{
	int i;
	double dmean=0;
	for(i=0;i<size;i++)
	{
		if(pbuf[i]<min) min=pbuf[i];
		if(pbuf[i]>max) max=pbuf[i];
		dmean+=pbuf[i];
	}
	mean+=(dmean/size);
}



//INPUT1: 1Input.mrc 2Output.mrc
//INPUT2: 1Input.mrc 2Output.mrc 3bGain

int main(int narg, char *argc[])
{

	if(narg==1)
    {
        printf("\n  Convert MRC file to 32bit format(mode 2)\n\n");
        printf("    INPUT 1: Input.mrc Output.mrc\n");
        printf("    INPUT 2: Input.mrc Output.mrc bGain(0/1)\n\n");
        printf("      *Note: 1) INPUT 1 will apply gain reference in header if available\n");
        printf("             2) bGain = 1: Apply gain reference in header if available; 0: Not\n");
        printf("             3) Support MRC mode 0,1,2,4,5,6\n\n");

        printf("    Wrote by Xueming Li @ UCSF Cheng Lab (01/02/2013)\n");
        return 1;
    }
    if(narg!=3 && narg!=4)
    {
        perror("   Missing arguments!\n");
        return 0;
    }
    
   bool bGain=1;
   if(narg==4) bGain=atoi(argc[3]);
   

	MRC input;
	if(input.open(argc[1],"rb")<=0)
	{
		printf("Failed to read %s . Abort\n",argc[1]);
		return 1;
	}
	
	MRCHeader header;
	input.getHeader(&header);
	
	int mode=input.getMode();
	int nx=input.getNx();
	int ny=input.getNy();
	int nz=input.getNz();
	int size=nx*ny;
	
	float *pGain=NULL;
	char *pExHeader=NULL;
	int ExHeaderSize=input.getSymdatasize();
	if(ExHeaderSize>0)
	{
		pExHeader=new char[ExHeaderSize];
	}
	
	
	if(bGain) 
	{	
		pGain=new float[size];
		if(input.readGainInHeader(pGain)==0)
		{
			delete [] pGain;
			pGain=NULL;
		}
		else
		{
			printf("Gain reference was read from header, \n");
		}
	}
	
	MRC output;
	output.open(argc[2],"wb");
	
	header.mode=2;
	header.nsymbt=ExHeaderSize-nx*ny*sizeof(float);
	if(header.nsymbt<0) header.nsymbt=ExHeaderSize;
	else printf("Gain reference in input header won't be written into output header!\n");
	output.setHeader(&header);
	if(header.nsymbt>0) output.wirteSymData(pExHeader);
	
	int i,n;
	float *buf=new float[size];
	for(n=0;n<nz;n++)
	{
		printf("...Read and write frame #%03d\n",n);
		input.read2DIm_32bit(buf,n);
		if(bGain && pGain!=NULL)
		{
			for(i=0;i<size;i++) buf[i]*=pGain[i];
		}
		output.write2DIm(buf,n);
	}
	
	output.close();
	input.close();
	
	delete [] buf;
	if(pGain!=NULL) delete [] pGain;
	if(pExHeader!=NULL) delete [] pExHeader;
	
	printf("Done!\n\n");
	
	


	return 0;
}













